window['adaptive'].desinWidth = 750; // 设计图宽度
window['adaptive'].baseFont = 18; // 没有缩放时的字体大小
window['adaptive'].maxWidth = 750; // 页面最大宽度 默认540
window['adaptive'].init(); // 调用初始化方法
