-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: wordpress
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lc_article`
--

DROP TABLE IF EXISTS `lc_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `title` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '标题',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '文章类型',
  `keyword` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '关键词',
  `content` text CHARACTER SET utf8 NOT NULL COMMENT '内容',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '时间',
  `show` int(11) NOT NULL DEFAULT '0' COMMENT '是否显示，0不显示/1显示',
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_article`
--

LOCK TABLES `lc_article` WRITE;
/*!40000 ALTER TABLE `lc_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_article_type`
--

DROP TABLE IF EXISTS `lc_article_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_article_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `name` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '名称',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `show` int(11) NOT NULL DEFAULT '0' COMMENT '是否显示，0不显示/1显示',
  `ico` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT 'help' COMMENT '类型图标',
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_article_type`
--

LOCK TABLES `lc_article_type` WRITE;
/*!40000 ALTER TABLE `lc_article_type` DISABLE KEYS */;
INSERT INTO `lc_article_type` VALUES (17,'首页弹窗',0,0,'help','2021-11-06 19:11:10'),(9,'最新公告',0,0,'help','2021-11-19 22:25:08');
/*!40000 ALTER TABLE `lc_article_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_bank`
--

DROP TABLE IF EXISTS `lc_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `bank` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '所属银行',
  `area` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无支行名称' COMMENT '支行名称',
  `account` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '银行卡号',
  `name` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '姓名预留',
  `mobile` int(11) NOT NULL DEFAULT '0' COMMENT '手机号 预留',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_bank`
--

LOCK TABLES `lc_bank` WRITE;
/*!40000 ALTER TABLE `lc_bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_cash`
--

DROP TABLE IF EXISTS `lc_cash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_cash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `name` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '提现姓名',
  `bid` int(11) NOT NULL DEFAULT '0' COMMENT '银行卡编号',
  `bank` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '所属银行',
  `area` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无支行名称' COMMENT '支行名称',
  `account` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '银行卡号',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态，0未提现/1已提现/2提现失败',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '提交时间',
  `time2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '处理时间',
  `warn` int(11) NOT NULL DEFAULT '0' COMMENT '充值提醒',
  `reaolae` text CHARACTER SET utf8 COMMENT '拒绝原因',
  `dzje` decimal(15,2) NOT NULL COMMENT '实际到账',
  `sxf` float(15,2) NOT NULL COMMENT '手续费',
  `sxfbfb` varchar(3) NOT NULL COMMENT '手续费百分百',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_cash`
--

LOCK TABLES `lc_cash` WRITE;
/*!40000 ALTER TABLE `lc_cash` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_cash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_finance`
--

DROP TABLE IF EXISTS `lc_finance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_finance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '类型,1收入/2支出',
  `reason` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '摘要',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '加入前余额',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_finance`
--

LOCK TABLES `lc_finance` WRITE;
/*!40000 ALTER TABLE `lc_finance` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_finance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_info`
--

DROP TABLE IF EXISTS `lc_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `webname` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '默认网站' COMMENT '网站名称',
  `gz_bankbz` int(11) NOT NULL DEFAULT '0',
  `gz_bankz` decimal(10,2) NOT NULL DEFAULT '0.00',
  `gz_bank` longtext CHARACTER SET utf8 COMMENT '银行入款支付描述',
  `gz_bank_type` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行',
  `gz_bank_name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行开户名',
  `gz_bank_account` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行账号',
  `gz_bank_status` int(11) NOT NULL DEFAULT '0' COMMENT '收款银行是否显示，0不显示/1显示',
  `domain` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT 'APP域名',
  `company` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '公司名称' COMMENT '公司名称',
  `tel` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '400-000-0000' COMMENT '客服电话',
  `address` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT '公司地址' COMMENT '公司地址',
  `notice` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT '网站公告' COMMENT '网站公告',
  `notice2` varchar(500) CHARACTER SET utf8 NOT NULL COMMENT '公告2',
  `service` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT 'http://www.yourdomain.com' COMMENT '客服地址',
  `app` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT 'http://www.yourdomain.com' COMMENT 'app下载链接',
  `appff` varchar(500) CHARACTER SET utf8 NOT NULL COMMENT 'app防封下载链接',
  `icp` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '京ICP备12345678号' COMMENT '备案号',
  `wechat` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '微信客服' COMMENT '微信客服',
  `qq` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '10000' COMMENT 'QQ客服',
  `cash` int(11) NOT NULL DEFAULT '0' COMMENT '最低提现金额',
  `alipay_bankbz` int(11) NOT NULL DEFAULT '0',
  `alipay_bank` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '银行入款支付描述',
  `alipay_bank_type` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行',
  `alipay_bank_name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行开户名',
  `alipay_bank_account` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行账号',
  `alipay_bank_status` int(11) NOT NULL DEFAULT '0' COMMENT '收款银行是否显示，0不显示/1显示',
  `alipay_bank_give` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `ranking` varchar(1000) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '排行榜',
  `contract` varchar(5000) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '合同模板',
  `pay_bank` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '银行入款支付描述',
  `pay_bank_type` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行',
  `pay_bank_name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行开户名',
  `pay_bank_account` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行账号',
  `pay_bank_status` int(11) NOT NULL DEFAULT '0' COMMENT '收款银行是否显示，0不显示/1显示',
  `pay_bank_give` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '赠送比例',
  `qr_wechat` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '微信扫码支付描述',
  `qr_wechattzlj` varchar(200) CHARACTER SET utf8 NOT NULL,
  `qr_wechat_img` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '微信二维码地址',
  `qr_wechat_status` int(11) NOT NULL DEFAULT '0' COMMENT '是否显示微信扫码,0隐藏/1显示',
  `qr_wechat_statustz` int(11) NOT NULL,
  `qr_alipay` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '支付宝扫码支付描述',
  `qr_alipaytzlj` varchar(200) CHARACTER SET utf8 NOT NULL,
  `qr_alipay_img` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '支付宝二维码地址',
  `qr_alipay_status` int(11) NOT NULL DEFAULT '0' COMMENT '是否显示支付宝扫码,0隐藏/1显示',
  `qr_alipay_statustz` int(11) NOT NULL,
  `online_wechat` int(11) NOT NULL DEFAULT '0' COMMENT '是否显示微信在线支付,0隐藏/1显示',
  `activity_url` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '#' COMMENT '活动链接',
  `activity_status` int(11) NOT NULL DEFAULT '0' COMMENT '活动是否开启,0关闭,1开启',
  `activity_img` varchar(255) DEFAULT NULL,
  `activity1_img` varchar(255) DEFAULT NULL,
  `activity1_status` int(11) NOT NULL DEFAULT '0' COMMENT '活动是否开启,0关闭,1开启',
  `activity1_url` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '#' COMMENT '活动链接',
  `jiesuan` int(11) NOT NULL DEFAULT '1' COMMENT '是否开启结算,0关闭/1开启',
  `web` int(11) NOT NULL DEFAULT '1' COMMENT '是否开启电脑版,0关闭/1开启',
  `sms` int(11) NOT NULL DEFAULT '1' COMMENT '短信开关,0关/1开',
  `reg` int(11) NOT NULL DEFAULT '1' COMMENT '注册开关',
  `cert` int(11) NOT NULL DEFAULT '0' COMMENT '实名认证接口开关，0关/1开',
  `linetoken` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '实名认证token',
  `bank` int(11) NOT NULL DEFAULT '0' COMMENT '银行卡认证开关，0关/1开',
  `banktoken` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '银行卡认证token',
  `template` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT 'one' COMMENT '手机模板',
  `video` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '视频地址',
  `smsname` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '短信签名',
  `smskeytz` varchar(200) CHARACTER SET utf8 NOT NULL,
  `smskey` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '短信密钥',
  `token` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '程序授权码',
  `jifendh` int(11) NOT NULL DEFAULT '0' COMMENT '积分兑换开关，0关/1开',
  `huiyuanshu` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '会员显示数量',
  `pay_bankbz` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '会员显示数量',
  `prize` tinyint(3) NOT NULL DEFAULT '0' COMMENT '抽奖开关，0关/1开',
  `itemclass` tinyint(3) NOT NULL DEFAULT '0' COMMENT '项目分类开关，0关/1开',
  `safesc` text CHARACTER SET utf8 NOT NULL COMMENT '安全认证代码',
  `authentication` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '实名秘钥',
  `bankkey` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '银行卡秘钥',
  `qdlcopen` int(1) DEFAULT '0' COMMENT '签到理财开关',
  `qdnum` int(1) DEFAULT '0' COMMENT '签到显示次数',
  `qdnotice` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '签到满公告',
  `wx_bankbz` int(11) NOT NULL DEFAULT '0',
  `wx_bank` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '银行入款支付描述',
  `wx_bank_type` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行',
  `wx_bank_name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行开户名',
  `wx_bank_account` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '收款银行账号',
  `wx_bank_status` int(11) NOT NULL DEFAULT '0' COMMENT '收款银行是否显示，0不显示/1显示',
  `wx_bank_give` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `seal_img` varchar(255) DEFAULT NULL COMMENT '公司章',
  `safe_seal_img` varchar(255) DEFAULT NULL COMMENT '保险章',
  `logo_img` varchar(255) DEFAULT NULL COMMENT '网站LOGO',
  `app_img` varchar(255) DEFAULT NULL COMMENT 'APP图标',
  `login_img` varchar(255) DEFAULT NULL COMMENT '登录图标',
  `news_img` varchar(255) DEFAULT NULL COMMENT '新闻页面底部图标',
  `min_recharge` int(11) DEFAULT '0' COMMENT '最低充值',
  `ban_ip` text NOT NULL,
  `contract_kj` text CHARACTER SET utf8,
  `appname` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT 'APP下载说明',
  `open_cash` int(11) NOT NULL DEFAULT '0',
  `cash_start` varchar(255) DEFAULT NULL,
  `cash_end` varchar(255) DEFAULT NULL,
  `cash_charge` int(11) NOT NULL DEFAULT '0',
  `cash_min` int(11) NOT NULL DEFAULT '0',
  `cash_max` int(11) NOT NULL DEFAULT '0',
  `cash_day_max` int(11) NOT NULL DEFAULT '0',
  `cash_max_num` int(11) NOT NULL DEFAULT '0',
  `recharge_amount` varchar(255) DEFAULT NULL,
  `recharge_min` int(11) NOT NULL,
  `recharge_max` int(11) NOT NULL DEFAULT '0',
  `order_charge` int(11) NOT NULL DEFAULT '0',
  `order_amount` varchar(255) DEFAULT NULL,
  `order_min` int(11) NOT NULL DEFAULT '0',
  `order_max` int(11) NOT NULL DEFAULT '0',
  `order_max_amount` int(11) NOT NULL DEFAULT '0',
  `order_max_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_info`
--

LOCK TABLES `lc_info` WRITE;
/*!40000 ALTER TABLE `lc_info` DISABLE KEYS */;
INSERT INTO `lc_info` VALUES (1,'-',0,0.00,'','0','0','0',0,'-','-','-','-','尊敬的用户： 为了给大家带来更好的体验，中国金荣这几天系统在升级......可能会给大家带来不便；金荣即将全新升级，页面会更趋于简单，功能会更加完善，体验感会更强哦，敬请期待！（请升级VIP会员）','','http://txlxcsp.xyz/index/index/home?visiter_id=&visiter_name=&avatar=&business_id=1&groupid=0&special=1&theme=7571f9','','','','','',0,0,'','','','',1,'0','','\n','0','联系在线客服','无','无',1,0.00,'','','',1,0,'','','',1,0,0,'#',0,'','',1,'#',1,0,0,1,0,'',0,'','one','无','','','','',1,'30','0',1,0,'','','',0,0,'',0,'','0','0','0',0,'0','','','/upload/390e85a1be7bd159/70f4d4461b5e52cf.png','/upload/390e85a1be7bd159/70f4d4461b5e52cf.png','/upload/390e85a1be7bd159/70f4d4461b5e52cf.png','',100,'','\n','',1,'10:00','22:00',0,100,999999,9999999,3,'100|1000|10000|50000|100000',100,999999999,0,'100|1000|10000|50000|100000',100,999999999,999999999,100);
/*!40000 ALTER TABLE `lc_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_invest`
--

DROP TABLE IF EXISTS `lc_invest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_invest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '项目ID',
  `title` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '项目标题',
  `number` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '合同编号',
  `money` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '投资金额',
  `day` int(11) NOT NULL DEFAULT '0' COMMENT '项目天数',
  `rate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '项目费率',
  `type1` int(11) NOT NULL DEFAULT '0' COMMENT '项目类型1',
  `type2` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '项目类型2',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '还款状态',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '投资时间',
  `time2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '到期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_invest`
--

LOCK TABLES `lc_invest` WRITE;
/*!40000 ALTER TABLE `lc_invest` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_invest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_invest_list`
--

DROP TABLE IF EXISTS `lc_invest_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_invest_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `iid` int(11) NOT NULL DEFAULT '0' COMMENT '投资记录ID',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '投资期数',
  `title` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '项目标题',
  `money1` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '待还利息',
  `money2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '待还本金',
  `time1` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '预计还款时间',
  `time2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '实际还款时间',
  `pay1` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '预计还款金额',
  `pay2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际还款金额',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '项目记录,0未还款/1还款',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_invest_list`
--

LOCK TABLES `lc_invest_list` WRITE;
/*!40000 ALTER TABLE `lc_invest_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_invest_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_item`
--

DROP TABLE IF EXISTS `lc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `title` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '标题',
  `desc` varchar(144) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '项目描述',
  `img` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT 'no_img.jpg' COMMENT '图片链接',
  `total` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `rate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '费率',
  `percent` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '模拟进度',
  `day` int(11) NOT NULL DEFAULT '0' COMMENT '期限',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '返款类型',
  `min` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '最小投资金额',
  `max` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '最大投资金额',
  `num` int(11) NOT NULL DEFAULT '1' COMMENT '最大投资次数',
  `guarantee` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '担保公司' COMMENT '担保公司',
  `limit` int(11) NOT NULL DEFAULT '0' COMMENT '最大购买分数',
  `content` text CHARACTER SET utf8,
  `red` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '投资送红包',
  `prize` int(11) NOT NULL DEFAULT '0' COMMENT '是否开启抽奖',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '是否开启积分',
  `fixedtime` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '固定结算时间',
  `fixedcontent` text CHARACTER SET utf8 COMMENT '结算说明',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '开始时间',
  `sort` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `jfbl` text CHARACTER SET utf8 NOT NULL COMMENT '积分比例',
  `value` int(10) NOT NULL COMMENT '积分比例',
  `invest1` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest2` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest3` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest4` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest5` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest6` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest7` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `invest8` decimal(5,2) DEFAULT '0.00' COMMENT '分润比例',
  `class` int(11) NOT NULL DEFAULT '0' COMMENT '项目分类',
  `red1` decimal(6,2) DEFAULT '0.00' COMMENT '邀请人一级红包',
  `red2` decimal(6,2) DEFAULT '0.00' COMMENT '邀请人2级红包',
  `red3` decimal(6,2) DEFAULT '0.00' COMMENT '邀请人3级红包',
  `red4` decimal(6,2) DEFAULT '0.00' COMMENT '邀请人4级红包',
  `auto` int(3) NOT NULL DEFAULT '0' COMMENT '自动拉满天数',
  `offvoucher` int(255) DEFAULT '0' COMMENT '抵用券开关 1开  0关',
  `usevoucher` int(255) DEFAULT '0' COMMENT '抵用券使用数量',
  `hysl` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_item`
--

LOCK TABLES `lc_item` WRITE;
/*!40000 ALTER TABLE `lc_item` DISABLE KEYS */;
INSERT INTO `lc_item` VALUES (1,'1','1','',1.00,1.00,1.00,1,1,1.00,1000000.00,1000,'中国人民保险（香港）有限公司',0,NULL,0.00,0,0,'2022-01-07 00:00:00','','2022-01-07 00:00:00',0,'1',0,1.00,1.00,1.00,0.00,0.00,0.00,0.00,0.00,1,1.00,1.00,1.00,0.00,1,0,0,'1');
/*!40000 ALTER TABLE `lc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_item_class`
--

DROP TABLE IF EXISTS `lc_item_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_item_class` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `img1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `note` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `add_time` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `color` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '#000',
  `sort` int(20) NOT NULL DEFAULT '0',
  `member_id` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '会员等级id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_item_class`
--

LOCK TABLES `lc_item_class` WRITE;
/*!40000 ALTER TABLE `lc_item_class` DISABLE KEYS */;
INSERT INTO `lc_item_class` VALUES (1,'新手项目',NULL,'新手项目','2020-05-14 17:40:36','#000',0,'8015'),(2,'稳定项目',NULL,'','2021-02-27 11:23:35','#000',0,'8015'),(3,'长期项目',NULL,'','2021-02-27 11:23:41','#000',0,'8015');
/*!40000 ALTER TABLE `lc_item_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_item_type`
--

DROP TABLE IF EXISTS `lc_item_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_item_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_item_type`
--

LOCK TABLES `lc_item_type` WRITE;
/*!40000 ALTER TABLE `lc_item_type` DISABLE KEYS */;
INSERT INTO `lc_item_type` VALUES (1,'按日付收益，保证金到期全额返还');
/*!40000 ALTER TABLE `lc_item_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_mall`
--

DROP TABLE IF EXISTS `lc_mall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_mall` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '无' COMMENT '标题',
  `img` varchar(255) NOT NULL DEFAULT 'no_img.jpg' COMMENT '图片链接',
  `total` int(11) NOT NULL DEFAULT '10000' COMMENT '总量',
  `min` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '保证金',
  `fixedcontent` text COMMENT '结算说明',
  `time` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '开始时间',
  `day` int(11) DEFAULT '1',
  `day_income` decimal(11,8) DEFAULT NULL,
  `stock` int(11) DEFAULT '10000',
  `power` decimal(11,2) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `cost` decimal(11,8) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '1000',
  `guarantee` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_mall`
--

LOCK TABLES `lc_mall` WRITE;
/*!40000 ALTER TABLE `lc_mall` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_mall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_mall_invest`
--

DROP TABLE IF EXISTS `lc_mall_invest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_mall_invest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '项目ID',
  `title` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '项目标题',
  `money` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '投资金额',
  `day` int(11) NOT NULL DEFAULT '0' COMMENT '项目天数',
  `day_income` decimal(11,8) NOT NULL DEFAULT '0.00000000' COMMENT '项目费率',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '还款状态',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '投资时间',
  `time2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '到期时间',
  `cost` decimal(11,8) DEFAULT NULL,
  `profit` decimal(11,8) DEFAULT NULL,
  `number` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `num` int(10) DEFAULT '0',
  `type` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_mall_invest`
--

LOCK TABLES `lc_mall_invest` WRITE;
/*!40000 ALTER TABLE `lc_mall_invest` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_mall_invest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_mall_invest_list`
--

DROP TABLE IF EXISTS `lc_mall_invest_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_mall_invest_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `iid` int(11) NOT NULL DEFAULT '0' COMMENT '投资记录ID',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '投资期数',
  `title` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '项目标题',
  `money1` decimal(10,8) NOT NULL DEFAULT '0.00000000' COMMENT '待还利息',
  `money2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '待还本金',
  `time1` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '预计还款时间',
  `time2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '实际还款时间',
  `pay1` decimal(10,8) NOT NULL DEFAULT '0.00000000' COMMENT '预计还款金额',
  `pay2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际还款金额',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '项目记录,0未还款/1还款',
  `tran_type` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_mall_invest_list`
--

LOCK TABLES `lc_mall_invest_list` WRITE;
/*!40000 ALTER TABLE `lc_mall_invest_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_mall_invest_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_msg`
--

DROP TABLE IF EXISTS `lc_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '消息标题',
  `phone` varchar(11) CHARACTER SET utf8 DEFAULT NULL COMMENT '接收账号',
  `content` text CHARACTER SET utf8 COMMENT '消息内容',
  `sort` int(11) DEFAULT '0' COMMENT '排序',
  `top` int(1) DEFAULT '0' COMMENT '置顶',
  `status` int(1) DEFAULT '0' COMMENT '0 未读 1已读',
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_msg`
--

LOCK TABLES `lc_msg` WRITE;
/*!40000 ALTER TABLE `lc_msg` DISABLE KEYS */;
INSERT INTO `lc_msg` VALUES (1,0,'隐私政策','','<div style=\"position: relative;\"><p style=\"margin-top: 0px; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>在此特别提醒您（用户）在注册成为用户之前，请认真阅读本《隐私协议》（以下简称“协议”），确保您充分理解本协议中各条款。请您审慎阅读并选择接受或不接受本协议。您的注册、登录、使用等行为将视为对本协议的接受，并同意接受本协议各项条款的约束。本协议约定 <span class=\"copyright copyright_dev\" data-v-be38c6d6=\"\" style=\"\">我司</span>与用户之间关于软件或服务的权利义务。“用户”是指注册、登录、使用本服务的个人。本协议可由本公司随时更新，更新后的协议条款一旦公布即代替原来的协议条款，恕不再另行通知，用户可在本公司产品中查阅最新版协议条款。在修改协议条款后，如果用户不接受修改后的条款，请立即停止使用本公司提供的服务，用户继续使用服务将被视为接受修改后的协议。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>第一 数据恢复信息的保密</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>您在使用本公司提供的数据恢复产品或服务时，用户须允许本公司使用该硬件设备包括但限于硬盘中的任何信息用于数据恢复，我司保证该信息的保密性，数据恢复之后，不论用户是否拷贝数据，我司都不留下该设备中任何数据的备份。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>第二 个人信息的收集</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>请您知悉，本公司收集您的以下个人信息是出于满足为您提供服务的需要以及改善产品和服务的目的，本公司十分重视对您隐私的保护。在本公司收集您的信息时，将严格遵守“合法、正当、必要”的原则。且您知悉，若您不提供本公司为您提供服务所需的相关信息，您的使用体验和效果可能因此而受到影响。考虑到本公司提供服务的相关性，您已同意，本公司将会收集您使用产品和服务时输入的或者以其他方式提供给我们的信息：</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>1 移动设备型号、设备名称、唯一标识符、浏览器类型、系统语言、操作系统版本、应用程序版本、WIFI网络环境、日志信息。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>2 在您注册或激活登录账户时，将收集您的个人注册信息，包括手机号、用户名、密码、用户头像、昵称。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>3 服务过程中，我们会记录您的地理位置信息。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>上述信息的收集在法律法规准许的前提下，本公司有权做任何变动，恕不另行通知。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>第三 数据信息的管理</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>1 本公司在中华人民共和国境内收集和产生的用户个人信息存储在中华人民共和国境内的服务器上。若确需向境外传输您的个人信息，将在事前获得您的授权，且按照有关法律法规政策的要求进行跨境数据传输，并对您的个人信息履行保密义务。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>2 对您的信息存储于本公司服务器期间，本公司将全力维护信息的安全，并有效确保信息的合理使用。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>3 未经过您的事先同意，我们不会将您的信息向第三方进行公开或转让，除非以下情形：</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（1） 事先获得您明确的同意或授权；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（2） 与国家安全、国防安全有关的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（3） 与公共安全、公共卫生、重大公共利益有关的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（4） 与犯罪侦查、起诉、审判和判决执行等有关的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（5） 所收集的个人信息是您自行向社会公众公开的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（6） 从合法公开披露的信息中收集您的个人信息，如合法的新闻报道，政府信息公开等渠道；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（7） 与本公司的关联方、合作伙伴及第三方服务供应商共享，但仅基于基本信息的共享；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>（8） 法律法规规定的其他情形。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>第四 个人隐私的保护</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>1、如果本公司发现或收到他人举报或投诉用户违反本隐私协议或违反使用协议约定的，本公司有权不经通知随时对相关内容，包括但不限于用户资料、发贴记录进行审查、删除，并视情节轻重对违规账号处以包括但不限于警告、账号封禁 、设备封禁 、功能封禁 的处罚，且通知用户处理结果。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>2、因违反用户协议被封禁的用户，可以自行与本公司联系。其中，被实施功能封禁的用户会在封禁期届满后自动恢复被封禁功能。被封禁用户可提交申诉，本公司将对申诉进行审查，并自行合理判断决定是否变更处罚措施。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>3、用户理解并同意，本公司有权依合理判断对违反有关法律法规或本协议规定的行为进行处罚，对违法违规的任何用户采取适当的法律行动，并依据法律法规保存有关信息向有关部门报告等，用户应承担由此而产生的一切法律责任。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>4、用户理解并同意，因用户违反本协议约定，导致或产生的任何第三方主张的任何索赔、要求或损失，包括合理的律师费，用户应当赔偿本公司与合作公司、关联公司，并使之免受损害。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>第五 用户发布信息须知</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>使用本公司提供的产品或服务过程当中，可能涉及用户自身信息的发布，在此约定：</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>用户不得制作、上传、复制、发布、传播如下法律、法规和政策禁止的内容：</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(1) 反对宪法所确定的基本原则的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(2) 危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(3) 损害国家荣誉和利益的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(4) 煽动民族仇恨、民族歧视，破坏民族团结的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(5) 破坏国家宗教政策，宣扬邪教和封建迷信的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(6) 散布谣言，扰乱社会秩序，破坏社会稳定的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(7) 散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(8) 侮辱或者诽谤他人，侵害他人合法权益的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(9) 含有法律、行政法规禁止的其他内容的信息。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>用户亦不得制作、上传、复制、发布、传播如下干扰“服务”正常运营，以及侵犯其他用户或第三方合法权益的内容：</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(1) 含有明示性或性暗示的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(2) 含有辱骂、恐吓、威胁内容的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(3) 含有骚扰、垃圾广告、恶意信息、诱骗信息的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(4) 涉及他人隐私、个人信息或资料的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(5) 侵害他人名誉权、肖像权、知识产权、商业秘密等合法权利的；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>(6) 含有其他干扰本服务正常运营和侵犯其他用户或第三方合法权益内容的信息。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>第六 其他须知</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>1、本公司郑重提醒用户注意本协议中免除责任和限制用户权利的条款，请用户仔细阅读，自主考虑风险。未成年人应在法定监护人的陪同下阅读本协议。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>2、本协议的效力、解释及纠纷的解决，适用于中华人民共和国大陆法律。若用户和本公司之间发生任何纠纷或争议，首先应友好协商解决，协商不成的，用户同意将纠纷或争议提交本公司住所地有管辖权的人民法院管辖。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>3、本协议的任何条款无论因何种原因无效或不具可执行性，其余条款仍有效，对双方具有约束力。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>4、 用户须确认拥有需要恢复数据的设备和数据的所有权；或确保经过设备或数据所有者本人授权；否则我司有权随时终止数据恢复服务，并保留追究该用户法律责任的权力；</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>本《隐私协议》版权由本公司所有，并保留一切对本《隐私协议》解释的权利。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>如您与我司就本《隐私协议》内容或其执行发生任何争议，双方应进行友好协商；协商不成时，任何一方均可向我司住所地有管辖权的人民法院提起诉讼。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>本《隐私协议》的各项条款具有可分割性，如果某一条款被适用法律认定为无效，则其他条款不受影响，应继续有效并执行。</font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font> </font></p><p style=\"margin-top: 1.6rem; margin-bottom: 1.6rem; font-family: &amp;quot;Segoe UI&amp;quot;, &amp;quot;Lucida Grande&amp;quot;, Helvetica, Arial, &amp;quot;Microsoft YaHei&amp;quot;, FreeSans, Arimo, &amp;quot;Droid Sans&amp;quot;, &amp;quot;wenquanyi micro hei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Hiragino Sans GB W3&amp;quot;, sans-serif; font-size: 14px;\" data-v-be38c6d6=\"\"><font>至此，您肯定已经详细阅读并已理解本《隐私协议》，并同意严格遵守各条款和条件。</font></p><uni-resize-sensor><div><div></div></div><div><div></div></div></uni-resize-sensor></div>',0,0,0,'2022-10-31 16:25:06'),(2,0,'关于我们','','<div style=\"position: relative;\"><font><span style=\"font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\">周大生珠宝股份有限公司成立于1999年，于2017年5月在深圳主板上市，目前，周大生品牌价值位于大陆珠宝品牌第一、大中华区第二，</span><br style=\"background-repeat: no-repeat; font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\"><span style=\"font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\">连续10年以两位数的增速，由2011年75.25亿增长至2021年638.05亿，同时也是国内最具规模的珠宝品牌运营商之一。周大生洞察市场需求，探寻时尚潮流，融合风格美学，</span><br style=\"background-repeat: no-repeat; font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\"><span style=\"font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\">业界独家研创 “情景风格珠宝”，更精准定位消费人群，更深度解析情感共鸣与场景需求。主要产品包括钻石镶嵌首饰、素金首饰。</span><br style=\"background-repeat: no-repeat; font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\"><span style=\"font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\">基于周大生的商业模式和品牌定位，将继续坚持以钻石为主力产品，比利时“LOVE100”星座极光百面切工钻石为核心产品，</span><br style=\"background-repeat: no-repeat; font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\"></font><p><span style=\"font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\"><font>黄金为人气产品，铂金、K金、翡翠、珍珠、彩宝为配套产品，不断丰富和完善产品线</font></span></p><p><span style=\"font-family: &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, sans-serif, Arial; font-size: 14px; text-align: center;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font>品牌文化：</font></span></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font>周大生名称源自《周易·系辞下》中的“天地之大德曰生”，寓意天地之间最伟大的德行，是哺育万物与爱护生命，而珠宝本身就是表达爱与美的使者</font></span></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><font><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">企业愿景：</span><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><br></span></font></p><p><font><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">缔造传世品牌，开创珠宝盛世，光耀华夏，与龙同飞</span><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><font><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">三人文化：</span><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><font><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">顾客是恩人，员工是亲人，领导是凡人</span><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><font><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">新三人文化：</span><br></font></p><p><font><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">理解人性，不战而胜；凝聚人心，不约而同；发挥人才，不召而至；</span><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><font><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">四个共同：</span><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><font><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">共同实现人生价值，共同追求家庭幸福，共同实现企业理想，共同效力国家富强</span><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><font><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">六条相处原则：</span><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><font><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\">尊重、沟通、真诚、友善、反省、自律</span><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><br></span></font></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font><br></font></span></p><p><span style=\"font-weight: 700; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font>八大工作原则：</font></span></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font>将心比心、角色转换；</font></span></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font>勤俭节约、崇尚实干；</font></span></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font>同步发展、落实反馈；</font></span></p><p><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 2em;\" data-v-eaf95d06=\"\"><font>独当一面、永不言败。</font></span></p><h3 class=\"title-text\" data-v-eaf95d06=\"\" style=\"margin: 0px; padding: 0px; font-size: 18px; font-family: &amp;quot;Microsoft YaHei&amp;quot;, SimHei, Verdana;\"><font><br></font></h3><div><font><br></font></div><div><span style=\"font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, &amp;quot;PingFang SC&amp;quot;, &amp;quot;Hiragino Sans GB&amp;quot;, &amp;quot;Microsoft YaHei&amp;quot;, &amp;quot;WenQuanYi Micro Hei&amp;quot;, sans-serif; font-size: 14px; text-indent: 28px;\" data-v-eaf95d06=\"\"><font>我们深信每一颗钻石都有它独一无二的美丽，都代表着一颗爱人的心。我们精心寻找每一颗美丽的钻石，用刻画艺术品的心情，用对待爱人般的耐性雕琢打磨切割，我们相信钻石对爱的祝福，于是在顶尖的工艺中融入这份珍爱。让这一颗颗钻石，如同光明美善的种子，唤醒每个人心中深藏的爱，拥有爱，分享爱，传递爱，它如阳光一样，贯穿整个生命，并指引你回到爱的精神家园。因爱而美，为爱而生！</font></span><br></div><uni-resize-sensor><div><div></div></div><div><div></div></div></uni-resize-sensor></div>',0,0,0,'2022-10-31 16:26:03');
/*!40000 ALTER TABLE `lc_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_msg_is`
--

DROP TABLE IF EXISTS `lc_msg_is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_msg_is` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_msg_is`
--

LOCK TABLES `lc_msg_is` WRITE;
/*!40000 ALTER TABLE `lc_msg_is` DISABLE KEYS */;
INSERT INTO `lc_msg_is` VALUES (19,12,26110),(20,1,2),(21,2,2),(22,2,3);
/*!40000 ALTER TABLE `lc_msg_is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_order`
--

DROP TABLE IF EXISTS `lc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_order` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `orderno` varchar(40) DEFAULT NULL COMMENT '订单编号',
  `uid` int(11) NOT NULL COMMENT '下单用户uid',
  `pid` int(11) NOT NULL COMMENT '产品ID',
  `ostyle` int(12) NOT NULL DEFAULT '0' COMMENT '0涨 1跌，',
  `buytime` int(20) DEFAULT NULL COMMENT '建仓',
  `onumber` int(20) DEFAULT NULL COMMENT '手数',
  `selltime` int(20) DEFAULT '0' COMMENT '平仓',
  `ostaus` int(11) DEFAULT NULL COMMENT '0交易，1平仓',
  `buyprice` double(20,6) DEFAULT NULL COMMENT '入仓价',
  `sellprice` varchar(20) DEFAULT NULL COMMENT '平仓价',
  `endprofit` varchar(20) DEFAULT '0.00' COMMENT '点数/分钟数',
  `endloss` double DEFAULT '0' COMMENT '盈亏比例',
  `fee` double(11,1) DEFAULT NULL COMMENT '总费用',
  `eid` float(11,2) NOT NULL COMMENT '1点位、2时间',
  `ptitle` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `commission` double(255,1) DEFAULT '0.0' COMMENT '佣金',
  `ploss` double(255,2) DEFAULT '0.00' COMMENT '盈亏',
  `display` int(11) DEFAULT '0' COMMENT '0,可查询，1不可查询',
  `isshow` int(1) DEFAULT '0',
  `is_win` tinyint(1) DEFAULT NULL COMMENT '是否盈利1盈利2亏损3无效',
  `kong_type` int(1) DEFAULT '0' COMMENT '0不空1盈利2亏损',
  `sx_fee` varchar(18) DEFAULT NULL COMMENT '手续费',
  `lossrate` double DEFAULT '0' COMMENT '最大亏损比例',
  `limit_points` int(11) DEFAULT NULL,
  `stop_points` int(11) DEFAULT NULL,
  `warn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uidd` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_order`
--

LOCK TABLES `lc_order` WRITE;
/*!40000 ALTER TABLE `lc_order` DISABLE KEYS */;
INSERT INTO `lc_order` VALUES (1,'2022103110125925866',2,3,0,1667182379,NULL,1667182679,1,8.498400,'8.1484','300',-3.1,100.0,2.00,'HT/火币',49900.0,-3.10,0,0,2,0,'0',3.1,NULL,NULL,0),(2,'2022103110130121989',2,3,0,1667182381,NULL,1667182681,1,8.498400,'8.6984','300',3.1,100.0,2.00,'HT/火币',49800.0,3.10,0,0,1,0,'0',3.1,NULL,NULL,0),(3,'2022103110130229546',2,3,0,1667182382,NULL,1667182682,1,8.498400,'8.7784','300',3.1,100.0,2.00,'HT/火币',49700.0,3.10,0,0,1,0,'0',3.1,NULL,NULL,0),(4,'2022103110182929423',2,3,1,1667182709,NULL,1667183009,1,8.536600,'8.1966','300',3.1,100.0,2.00,'HT/火币',49903.1,3.10,0,0,1,0,'0',3.1,NULL,NULL,0),(5,'2022103110183029339',2,3,1,1667182710,NULL,1667183010,1,8.536600,'7.7266','300',3.1,100.0,2.00,'HT/火币',49803.1,3.10,0,0,1,0,'0',3.1,NULL,NULL,0),(6,'2022103110183125859',2,3,1,1667182711,NULL,1667183011,1,8.536600,'7.8966','300',3.1,100.0,2.00,'HT/火币',49703.1,3.10,0,0,1,0,'0',3.1,NULL,NULL,0),(7,'2022103111575325440',2,15,1,1667188673,NULL,1667188733,1,35.962900,'36.2029','60',-10,100.0,2.00,'Gold/黄金',49912.4,-10.00,0,0,2,0,'0',10,NULL,NULL,0),(8,'2022103112342728537',2,1,0,1667190867,NULL,1667191167,1,20500.000000,'20500.35','300',3.2,100.0,2.00,'BTC/USDT',49812.4,3.20,0,0,1,0,'0',3.2,NULL,NULL,0),(9,'2022103113090624448',2,15,0,1667192946,NULL,1667193006,1,35.962900,'35.4629','60',-10,100.0,2.00,'Gold/黄金',49712.4,-10.00,0,0,2,0,'0',10,NULL,NULL,0),(10,'2022103113091823339',2,15,0,1667192958,NULL,1667194158,1,35.962900,'36.2716','1200',160,1000.0,2.00,'Gold/黄金',48712.4,160.00,0,0,1,0,'0',16,NULL,NULL,0),(11,'2022103113092726936',2,15,1,1667192967,NULL,1667194167,1,35.962900,'35.4229','1200',16,100.0,2.00,'Gold/黄金',48612.4,16.00,0,0,1,0,'0',16,NULL,NULL,0),(12,'2022103115121622417',2,1,0,1667200336,NULL,1667200636,1,20485.000000,'20485.17','300',3.2,100.0,2.00,'珍珠/Pearl',50071.6,3.20,0,0,1,0,'0',3.2,NULL,NULL,0),(13,'2022103116333921296',2,1,1,1667205219,NULL,1667205519,1,20470.000000,'20469.56','300',3.2,100.0,2.00,'珍珠/Pearl',50074.8,3.20,0,0,1,0,'0',3.2,NULL,NULL,0),(14,'2022103116540128265',2,15,1,1667206441,NULL,1667206501,1,35.730600,'36.5306','60',-10,100.0,2.00,'Gold/黄金',50078.0,-10.00,0,0,2,0,'0',10,NULL,NULL,0),(15,'2022110113433721707',2,15,0,1667281417,NULL,1667281477,1,34.729200,'34.3092','60',-10,100.0,2.00,'Gold/黄金',50068.0,-10.00,0,0,2,0,'0',10,NULL,NULL,0);
/*!40000 ALTER TABLE `lc_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_order_log`
--

DROP TABLE IF EXISTS `lc_order_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_order_log` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) DEFAULT NULL,
  `oid` mediumint(8) DEFAULT NULL,
  `addprice` decimal(10,2) DEFAULT NULL,
  `addpoint` decimal(10,2) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `user_money` decimal(20,2) DEFAULT NULL,
  `is_delete` int(2) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=gbk ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_order_log`
--

LOCK TABLES `lc_order_log` WRITE;
/*!40000 ALTER TABLE `lc_order_log` DISABLE KEYS */;
INSERT INTO `lc_order_log` VALUES (1,2,1,96.90,0.00,1667182680,49796.90,0),(2,2,2,103.10,0.00,1667182682,49900.00,0),(3,2,3,103.10,0.00,1667182683,50003.10,0),(4,2,4,103.10,0.00,1667183010,49806.20,0),(5,2,5,103.10,0.00,1667183011,49909.30,0),(6,2,6,103.10,0.00,1667183012,50012.40,0),(7,2,7,90.00,0.00,1667193830,48702.40,0),(8,2,8,103.20,0.00,1667193830,48805.60,0),(9,2,9,90.00,0.00,1667193830,48895.60,0),(10,2,10,1160.00,0.00,1667194159,50055.60,0),(11,2,11,116.00,0.00,1667194168,50171.60,0),(12,2,12,103.20,0.00,1667200637,50174.80,0),(13,2,13,103.20,0.00,1667205520,50178.00,0),(14,2,14,90.00,0.00,1667206502,50168.00,0),(15,2,15,90.00,0.00,1667281478,50158.00,0);
/*!40000 ALTER TABLE `lc_order_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_prize`
--

DROP TABLE IF EXISTS `lc_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_prize` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `credit` int(11) NOT NULL DEFAULT '0' COMMENT '所需积分',
  `endtime` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '结束时间',
  `rule` varchar(2000) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '抽奖规则',
  `content` varchar(2000) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '抽奖记录',
  `name1` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '一等奖' COMMENT '一等奖名称',
  `type1` int(11) NOT NULL DEFAULT '1' COMMENT '奖品类型，1现金/2余额',
  `money1` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '中奖金额',
  `odds1` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '一等奖中奖概率',
  `reason1` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '一等奖描述' COMMENT '一等奖描述',
  `name2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '二等奖' COMMENT '二等奖名称',
  `type2` int(11) NOT NULL DEFAULT '1' COMMENT '奖品类型，1现金/2余额',
  `money2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '中奖金额',
  `odds2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '二等奖中奖概率',
  `reason2` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '二等奖描述' COMMENT '二等奖描述',
  `name3` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '三等奖' COMMENT '三等奖名称',
  `type3` int(11) NOT NULL DEFAULT '1' COMMENT '奖品类型，1现金/2余额',
  `money3` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '中奖金额',
  `odds3` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '三等奖中奖概率',
  `reason3` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '三等奖描述' COMMENT '三等奖描述',
  `name4` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '四等奖' COMMENT '四等奖名称',
  `type4` int(11) NOT NULL DEFAULT '1' COMMENT '奖品类型，1现金/2余额',
  `money4` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '中奖金额',
  `odds4` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '四等奖中奖概率',
  `reason4` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '四等奖描述' COMMENT '四等奖描述',
  `name5` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '五等奖' COMMENT '五等奖名称',
  `type5` int(11) NOT NULL DEFAULT '1' COMMENT '奖品类型，1现金/2余额',
  `money5` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '中奖金额',
  `odds5` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '五等奖中奖概率',
  `reason5` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '五等奖描述' COMMENT '五等奖描述',
  `name6` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '六等奖' COMMENT '六等奖名称',
  `type6` int(255) NOT NULL DEFAULT '1',
  `money6` decimal(11,2) NOT NULL DEFAULT '0.00',
  `odds6` decimal(11,2) NOT NULL DEFAULT '0.00',
  `reason6` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_prize`
--

LOCK TABLES `lc_prize` WRITE;
/*!40000 ALTER TABLE `lc_prize` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_prize_list`
--

DROP TABLE IF EXISTS `lc_prize_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_prize_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `item` int(11) NOT NULL DEFAULT '0' COMMENT '中奖编号',
  `name` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '中奖名称',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '中奖类型',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '中奖金额',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '抽奖时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_prize_list`
--

LOCK TABLES `lc_prize_list` WRITE;
/*!40000 ALTER TABLE `lc_prize_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_prize_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_product`
--

DROP TABLE IF EXISTS `lc_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `code` varchar(18) DEFAULT NULL COMMENT ' 产品代码',
  `img` varchar(255) DEFAULT NULL COMMENT '各种货币的图片',
  `point_low` varchar(18) DEFAULT '0.00000' COMMENT '波动最小值',
  `point_top` varchar(18) DEFAULT '0.00000' COMMENT '波动最大值',
  `rands` varchar(18) DEFAULT '0.00000' COMMENT '随机波动范围',
  `protime_1` decimal(5,2) NOT NULL DEFAULT '0.00',
  `protime_2` decimal(5,2) NOT NULL DEFAULT '0.00',
  `protime_3` decimal(5,2) NOT NULL DEFAULT '0.00',
  `protime_4` decimal(5,2) NOT NULL DEFAULT '0.00',
  `proscale_1` varchar(255) DEFAULT NULL,
  `proscale_2` varchar(255) DEFAULT NULL,
  `proscale_3` varchar(255) DEFAULT NULL,
  `proscale_4` varchar(255) DEFAULT NULL,
  `lossrate_1` varchar(255) DEFAULT NULL,
  `lossrate_2` varchar(255) DEFAULT NULL,
  `lossrate_3` varchar(255) DEFAULT NULL,
  `lossrate_4` varchar(255) DEFAULT NULL,
  `opentime_1` varchar(255) DEFAULT NULL,
  `opentime_2` varchar(255) DEFAULT NULL,
  `opentime_3` varchar(255) DEFAULT NULL,
  `opentime_4` varchar(255) DEFAULT NULL,
  `opentime_5` varchar(255) DEFAULT NULL,
  `opentime_6` varchar(255) DEFAULT NULL,
  `opentime_7` varchar(255) DEFAULT NULL,
  `content` text COMMENT '备注',
  `Price` varchar(25) DEFAULT NULL,
  `Open` varchar(25) DEFAULT NULL,
  `Close` varchar(25) DEFAULT NULL,
  `High` varchar(25) DEFAULT NULL,
  `Low` varchar(25) DEFAULT NULL,
  `Diff` varchar(25) DEFAULT NULL,
  `DiffRate` varchar(25) DEFAULT NULL,
  `UpdateTime` int(11) NOT NULL DEFAULT '0',
  `is_deal` int(11) NOT NULL DEFAULT '0',
  `isopen` int(1) DEFAULT '1',
  `sort` int(11) NOT NULL DEFAULT '0',
  `time` int(11) DEFAULT NULL COMMENT '添加时间',
  `isdelete` int(1) DEFAULT '0',
  `iskq` int(11) DEFAULT '0' COMMENT '1：开启，0关闭',
  `showps` int(2) DEFAULT '0' COMMENT '前台显示盈亏比',
  `showps2` int(1) DEFAULT '0',
  `upps` varchar(32) DEFAULT NULL,
  `downps` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_product`
--

LOCK TABLES `lc_product` WRITE;
/*!40000 ALTER TABLE `lc_product` DISABLE KEYS */;
INSERT INTO `lc_product` VALUES (1,'珍珠/Pearl','btc_usdt','/upload/cb471aced6cb3209/a2c99406dae1fbc8.jpg','0.01','0.1','0.8',1.00,20.00,30.00,0.00,'3.2','5.1','8.6','11.9','3.2','5.1','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','20610','20399.99','20399.99','20657.76','20320.72','0','0',1667284693,0,1,17,NULL,0,1,0,0,'',''),(2,'ETH/以太坊','eth_usdt','/upload/3ab6c4924a4341ba/10d28a90ac5d7405.png','0.01','0.3','0.8',5.00,10.00,15.00,20.00,'3.6','5.8','8.8','11.9','3.6','5.8','8.8','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','1594.8','1568.96','1569.33','1604.8','1550.53','0','0',1667284693,0,1,13,NULL,0,0,0,0,'',''),(3,'HT/火币','ht_usdt','/upload/cb815718b390a2b7/5e8e14f7fff5d9e6.png','0.01','0.6','0.9',5.00,10.00,15.00,20.00,'3.1','5.3','8.6','11.9','3.1','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','8.5947','8.7189','8.7172','8.7667','8.4999','0','0',1667284693,0,1,0,NULL,0,0,0,0,'',''),(4,'DOT/波卡','dot_usdt','/upload/a209eb0fdf7ababc/75d9988aee7d9d39.png','0.01','0.2','0.9',5.00,10.00,15.00,20.00,'3.2','5.6','8.8','11.9','3.2','5.6','8.8','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','6.6777','6.6472','6.6477','6.7011','6.5668','0','0',1667284692,0,1,14,NULL,0,0,0,0,'',''),(5,'Karat gold/K金','link_usdt','/upload/03ca1c0d63e0f2f8/69bb3379e0389b6e.jpg','0.01','0.5','0.9',1.00,20.00,30.00,0.00,'','','','','','','','','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','7.8013','8.0108','8.0089','8.0894','7.7195','0','0',1667284692,0,1,19,NULL,0,1,0,0,'',''),(9,'Platinum/铂金','bsv_usdt','/upload/aad401ef620022d2/922bf6a8ca00c68e.jpg','0.01','0.6','0.8',1.00,20.00,30.00,0.00,'3.1','5.3','8.6','11.9','3.1','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','47.8267','47.2516','47.2753','48.7443','47.2069','0','0',1667284692,0,1,12,NULL,0,1,0,0,'',''),(10,'NYS/白银','eos_usdt','/upload/90c12eb3f65d6aca/d0fbbd1688b0548c.jpg','0.01','0.8','0.8',1.00,20.00,30.00,0.00,'3.2','5.3','8.6','11.9','3.2','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','1.1621','1.1173','1.1176','1.1811','1.1147','0','0',1667284691,0,1,8,NULL,0,1,0,0,'',''),(11,'NE/新能源','xmr_usdt','/upload/0c7ee8fa895d2bc9/0a44e082b1a6a3a5.png','0.01','0.8','0.9',5.00,10.00,15.00,20.00,'3.2','5.3','8.6','11.9','3.2','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','259.18','239.55','239.58','264.51','238.9','0','0',1650944880,0,1,6,NULL,0,0,0,0,'',''),(12,'DASH','dash_usdt','/upload/52e3c144ef83a3f7/77774d45519030e6.png','0.01','0.6','0.8',5.00,10.00,15.00,20.00,'3.2','5.2','8.6','11.9','3.2','5.2','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','98.41','97.24','97.24','99.99','97.08','0','0',1650944880,0,1,21,NULL,0,0,0,0,'',''),(13,'宝石/Gemstone','zec_usdt','/upload/0005d4cf53eb34b4/b106f476032ca61c.jpg','0.01','0.6','0.8',1.00,20.00,30.00,0.00,'3.2','5.3','8.6','11.9','3.2','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','163.64','151.07','151.24','166.76','150.06','0','0',1650944880,0,1,20,NULL,0,1,0,0,'',''),(14,'ETC/USDT','etc_usdt','/upload/0d6cbb1ec4e8c14c/52882f95303e2cdc.png','0.01','0.6','0.8',5.00,10.00,15.00,20.00,'3.2','5.3','8.6','11.9','3.2','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','24.4843','24.1638','24.1573','24.7625','23.9317','0','0',1667284690,0,1,15,NULL,0,0,0,0,'',''),(15,'Gold/黄金','ksm_usdt','/upload/34de6ecc0ec8654f/8166e60c5d9aefdc.jpg','0.01','0.6','0.8',1.00,20.00,30.00,0.00,'85','90','95','0.00','85','90','95','0.00','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~07:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~07:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','34.7196','35.7569','35.7546','36.1071','34.2872','0','0',1667284690,0,1,1,NULL,0,1,0,0,'',''),(18,'DOGE/狗狗币','iota_usdt','/upload/81a008b6aa150c26/1b64a4785944704e.png','0.01','0.6','0.8',5.00,10.00,15.00,20.00,'3.2','5.3','8.6','11.9','3.2','5.3','8.6','11.9','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','00:00:00~03:00:00|08:00:00~23:59:59','','0.2606','0.2584','0.2583','0.2612','0.2556','0','0',1667284688,0,1,9,NULL,0,0,0,0,'','');
/*!40000 ALTER TABLE `lc_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_recharge`
--

DROP TABLE IF EXISTS `lc_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '充值金额',
  `type` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '付款方式',
  `orderid` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '订单编号',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '充值状态，0未充值/1已充值',
  `warn` int(11) NOT NULL DEFAULT '0' COMMENT '充值提醒',
  `reason` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '充值摘要',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '提交时间',
  `time2` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '审核时间',
  `reaolae` text COMMENT '拒绝原因',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_recharge`
--

LOCK TABLES `lc_recharge` WRITE;
/*!40000 ALTER TABLE `lc_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_reward`
--

DROP TABLE IF EXISTS `lc_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_reward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `register` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '用户注册',
  `register2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '邀请注册',
  `recharge` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '充值奖励',
  `invest1` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '投资一级奖励',
  `invest2` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '投资二级奖励',
  `invest3` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '投资三级奖励',
  `qiandao` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '每日签到奖励',
  `registerzzz` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '0.00' COMMENT '用户注册',
  `shimingsong` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '每日签到奖励',
  `seetime` int(11) NOT NULL DEFAULT '0' COMMENT '观看时间',
  `newsmoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '观看新闻领取金额',
  `getnum` int(11) NOT NULL DEFAULT '0' COMMENT '新闻领取次数',
  `isobse` int(255) NOT NULL DEFAULT '0' COMMENT '新闻开关',
  `isvoucher` int(255) NOT NULL DEFAULT '0' COMMENT '抵用券开关',
  `voucher` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抵用券金额',
  `vouchernum` int(11) DEFAULT '0' COMMENT '首次注册送抵用券数量',
  `newsmoneytwo` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_reward`
--

LOCK TABLES `lc_reward` WRITE;
/*!40000 ALTER TABLE `lc_reward` DISABLE KEYS */;
INSERT INTO `lc_reward` VALUES (1,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'0',0.00,0,0.00,0,0,0,0.00,0,0.00);
/*!40000 ALTER TABLE `lc_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_risk`
--

DROP TABLE IF EXISTS `lc_risk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_risk` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `to_win` text CHARACTER SET utf8 COMMENT '指定客户赢利',
  `to_loss` text CHARACTER SET utf8 COMMENT '指定客户亏损',
  `chance` text CHARACTER SET utf8 COMMENT '风控概率',
  `min_price` varchar(18) CHARACTER SET utf8 DEFAULT NULL COMMENT '最小风控值',
  `qybl` varchar(255) DEFAULT NULL COMMENT '全赢比例',
  `qkbl` varchar(255) DEFAULT NULL COMMENT '全亏比例',
  `wenyin` varchar(255) DEFAULT NULL COMMENT '稳赢时间段',
  `wenshu` varchar(255) DEFAULT NULL COMMENT '稳输时间段',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_risk`
--

LOCK TABLES `lc_risk` WRITE;
/*!40000 ALTER TABLE `lc_risk` DISABLE KEYS */;
INSERT INTO `lc_risk` VALUES (1,'','','100-500:50|1001-10000:50|10001-50000:50|50001-10000000000:50','100','100','100','','');
/*!40000 ALTER TABLE `lc_risk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_see_log`
--

DROP TABLE IF EXISTS `lc_see_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_see_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `dateline` bigint(20) NOT NULL,
  `money` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_see_log`
--

LOCK TABLES `lc_see_log` WRITE;
/*!40000 ALTER TABLE `lc_see_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_see_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_shop`
--

DROP TABLE IF EXISTS `lc_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `title` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '标题',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '类型,1现金/2实物',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '积分送现金',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '所需积分',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '剩余数量',
  `img` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT 'noimg.jpg' COMMENT '封面',
  `content` varchar(10000) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '内容',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_shop`
--

LOCK TABLES `lc_shop` WRITE;
/*!40000 ALTER TABLE `lc_shop` DISABLE KEYS */;
INSERT INTO `lc_shop` VALUES (4,'100元现金红包',1,100.00,888,8549,'/upload/e6316c9f38eb0d6c/c26318e22e4bdbef.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',1),(5,'150元话费',2,0.00,13888,8388,'/upload/aa7fed96326c8115/e314fb7e3a16992d.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',2),(6,'300元现金红包',1,300.00,28888,8880,'/upload/d367529caaeecce2/afb2b3f46849f6a3.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',3),(7,'500元话费',2,0.00,58888,8100,'/upload/a7c1999db4e87568/7a26c8f280289318.png','<p>兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',4),(8,'888元现金红包',1,888.00,88888,7980,'/upload/868da1d6df548cd8/0357dc89e9e7464d.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',5),(9,'1888元现金红包',1,1888.00,388888,8010,'/upload/57e1256705f1320e/81753ca18388af32.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',6),(10,'价值3499元美的微波炉烤箱一体机 ',2,0.00,588888,7500,'/upload/58ab3e2871731fac/64e19ce7d596aa88.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',7),(11,'价值5488元华为P30Pro8GB+256GB一部',2,0.00,888888,5000,'/upload/130d9770c84c523e/cf85df9bf6ceb343.png','<p>温馨提示：兑换现金红包由系统直接到您的个人中心余额中（可用于投资或者提现），兑换实物请联系在线客服兑换。</p>\r\n',8);
/*!40000 ALTER TABLE `lc_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_shop_order`
--

DROP TABLE IF EXISTS `lc_shop_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_shop_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `gid` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `goods` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '商品名称',
  `img` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT 'noimg.jpg' COMMENT '商品图片',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '商品类型',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '兑换现金',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '兑换时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_shop_order`
--

LOCK TABLES `lc_shop_order` WRITE;
/*!40000 ALTER TABLE `lc_shop_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_shop_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_slide`
--

DROP TABLE IF EXISTS `lc_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `path` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '#' COMMENT '图片路径',
  `url` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '#' COMMENT '图片链接',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '图片类型，1电脑/2手机',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `show` int(11) NOT NULL DEFAULT '0' COMMENT '显示，0不显示/1显示',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_slide`
--

LOCK TABLES `lc_slide` WRITE;
/*!40000 ALTER TABLE `lc_slide` DISABLE KEYS */;
INSERT INTO `lc_slide` VALUES (32,'/upload/6a94ef1b8623370f/6137cc4b4b3bd7d2.png','#',0,2,1),(31,'/upload/7e7ad801fe16c6cb/8ae19afe2400ec87.png','#',0,3,1),(33,'/upload/fe1acb699dd09b0f/c1fb253c18320e30.png','#',0,1,1);
/*!40000 ALTER TABLE `lc_slide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_sms`
--

DROP TABLE IF EXISTS `lc_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_sms` (
  `id` int(10) unsigned NOT NULL COMMENT '序号',
  `type` varchar(20) NOT NULL DEFAULT '无' COMMENT '短信类型',
  `msg` varchar(80) NOT NULL DEFAULT '无' COMMENT '内容',
  `code` varchar(20) NOT NULL DEFAULT '0' COMMENT '编码',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '短息状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='短信模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_sms`
--

LOCK TABLES `lc_sms` WRITE;
/*!40000 ALTER TABLE `lc_sms` DISABLE KEYS */;
INSERT INTO `lc_sms` VALUES (1,'用户注册','您的验证码是###，如非本人操作，请忽略本短信','18001',0),(2,'投资成功','您购买的“###”项目已成功！','18002',0),(3,'收益提醒','您的收益###元已到账，请登录会员中心查看！','18003',0),(4,'找回密码','您本次找回密码的验证码是：###，如非本人操作，请忽略本信息！','18004',0),(5,'充值成功提醒','您充值的###元已到账，请登入会员中心查收！','18005',0),(6,'充值失败提醒','尊敬的会员：您充值的###元未支付成功，请提交订单后用微　信支付宝或手机银行进行付款，支付对应金额（请忽略风控提示放心支付），如有疑问，请咨询在线客服！','18006',0),(7,'提现成功提醒','您申请的提现###元已到账，请您核实查收！','18007',0),(8,'提现失败提现','您申请的提现###元未成功，请联系在线客服！','18008',0),(9,'提现确定短信','您的提现验证码是：###，如非本人操作，请忽泄露信息！','18009',0);
/*!40000 ALTER TABLE `lc_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_sms_list`
--

DROP TABLE IF EXISTS `lc_sms_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_sms_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `phone` varchar(11) NOT NULL DEFAULT '无' COMMENT '手机号码',
  `msg` varchar(100) NOT NULL DEFAULT '无' COMMENT '短信记录',
  `code` varchar(100) NOT NULL DEFAULT '0' COMMENT '返回代码',
  `ip` varchar(20) NOT NULL DEFAULT '0' COMMENT 'IP',
  `time` varchar(20) NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '发送时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='短信记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_sms_list`
--

LOCK TABLES `lc_sms_list` WRITE;
/*!40000 ALTER TABLE `lc_sms_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_sms_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_user`
--

DROP TABLE IF EXISTS `lc_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `phone` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '手机号 账号',
  `alipay` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '姓名',
  `idcard` varchar(18) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '身份证号码',
  `auth` int(11) NOT NULL DEFAULT '0' COMMENT '是否认证,0未认证/1已认证',
  `password` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '登录密码',
  `password2` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '交易密码',
  `top` int(11) NOT NULL DEFAULT '0' COMMENT '推荐人',
  `qq` varchar(15) CHARACTER SET utf8 DEFAULT '' COMMENT 'qq',
  `member` int(11) NOT NULL DEFAULT '0' COMMENT '会员等级',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `frozenmoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `value` int(11) NOT NULL DEFAULT '0' COMMENT '成长值',
  `income` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总收益金额',
  `logintime` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '登录时间',
  `clock` int(11) NOT NULL DEFAULT '0' COMMENT '是否锁定,0否/1是',
  `qiandao` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '签到时间',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `prize` int(11) NOT NULL DEFAULT '0' COMMENT '抽奖次数',
  `ip` varchar(20) CHARACTER SET utf8 DEFAULT '0' COMMENT 'IP',
  `time` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '注册时间',
  `mwpassword` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '登录密码',
  `mwpassword2` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '登录密码',
  `country` varchar(30) CHARACTER SET utf8 DEFAULT '' COMMENT '国家',
  `region` varchar(50) CHARACTER SET utf8 DEFAULT '' COMMENT '省份',
  `city` varchar(50) CHARACTER SET utf8 DEFAULT '' COMMENT '城市',
  `county` varchar(50) CHARACTER SET utf8 DEFAULT '' COMMENT '县',
  `msgcount` int(11) DEFAULT '0' COMMENT '未读消息',
  `qdnum` int(10) DEFAULT '0' COMMENT '签到次数',
  `btc` decimal(11,8) DEFAULT '0.00000000',
  `isjy` int(11) DEFAULT '0' COMMENT '交易开启0，1为禁止交易',
  `loginip` varchar(20) CHARACTER SET utf8 DEFAULT '0' COMMENT 'IP',
  `robot` int(2) DEFAULT '0' COMMENT '真人=0假人=1？',
  `zcly` varchar(25) NOT NULL COMMENT '注册来源',
  `phones` bigint(19) DEFAULT NULL,
  `access_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `phone` (`phone`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_user`
--

LOCK TABLES `lc_user` WRITE;
/*!40000 ALTER TABLE `lc_user` DISABLE KEYS */;
INSERT INTO `lc_user` VALUES (2,'123456','','','无',0,'e10adc3949ba59abbe56e057f20f883e','e10adc3949ba59abbe56e057f20f883e',0,'',8015,50158.00,0.00,0,0.00,'1667283635',1,'0',0,0,'0.0.0.0','2022-10-22 23:12:10','123456','123456','','','','',0,0,0.00000000,0,'0.0.0.0',0,'127.0.0.1',123456,1667283635);
/*!40000 ALTER TABLE `lc_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_user_member`
--

DROP TABLE IF EXISTS `lc_user_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_user_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `name` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '无' COMMENT '等级名称',
  `value` int(11) NOT NULL DEFAULT '0' COMMENT '等级积分',
  `rate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '等级加息利率',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8017 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_user_member`
--

LOCK TABLES `lc_user_member` WRITE;
/*!40000 ALTER TABLE `lc_user_member` DISABLE KEYS */;
INSERT INTO `lc_user_member` VALUES (8003,'VIP1',20000,0.03),(8004,'VIP2',150000,0.06),(8008,'VIP3',500000,0.15),(8009,'VIP4',1000000,0.26),(8010,'VIP5',2000000,0.55),(8011,'VIP6',5000000,1.02),(8012,'VIP7',8000000,1.58),(8014,'VIP8',10000000,2.58),(8015,'普通会员',0,0.00),(8016,'VIP0',100,0.00);
/*!40000 ALTER TABLE `lc_user_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_voucher`
--

DROP TABLE IF EXISTS `lc_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_voucher` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `money` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '优惠券金额',
  `dateline` bigint(20) NOT NULL COMMENT '领取时间',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1未使用  2已使用',
  `xid` int(11) DEFAULT NULL COMMENT '投资项目ID',
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '投资项目标题',
  PRIMARY KEY (`vid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_voucher`
--

LOCK TABLES `lc_voucher` WRITE;
/*!40000 ALTER TABLE `lc_voucher` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_voucher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_yuebao`
--

DROP TABLE IF EXISTS `lc_yuebao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_yuebao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `lily` varchar(266) NOT NULL,
  `days` varchar(255) NOT NULL,
  `advise` int(2) DEFAULT '0' COMMENT '推荐',
  `lowmoney` int(8) DEFAULT '0' COMMENT '最低金额',
  `stars` int(1) DEFAULT '0',
  `addtime` bigint(15) DEFAULT '0',
  `status` int(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_yuebao`
--

LOCK TABLES `lc_yuebao` WRITE;
/*!40000 ALTER TABLE `lc_yuebao` DISABLE KEYS */;
INSERT INTO `lc_yuebao` VALUES (12,'利息宝1天','2','1',0,0,1,1635415281,1),(13,'利息宝30天','2.5','30',0,100,1,1635415278,1),(14,'利息宝180天','6','180',0,1000,1,1635415275,1),(15,'利息宝365天','15','365',0,10000,1,1635415271,1);
/*!40000 ALTER TABLE `lc_yuebao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_yuebao_lists`
--

DROP TABLE IF EXISTS `lc_yuebao_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_yuebao_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `yuebaoid` int(11) DEFAULT NULL COMMENT '余额宝产品ID',
  `yebtitle` varchar(128) DEFAULT NULL COMMENT '余额宝名称',
  `lily` varchar(50) DEFAULT NULL COMMENT '利率',
  `money` int(11) DEFAULT NULL COMMENT '金额',
  `days` int(11) DEFAULT NULL COMMENT '天数',
  `start_time` varchar(15) DEFAULT NULL COMMENT '开始时间',
  `end_time` varchar(15) DEFAULT NULL COMMENT '结束时间',
  `nowprofit` float DEFAULT '0' COMMENT '当前收益',
  `finishprofit` float DEFAULT '0' COMMENT '预期收益',
  `status` char(1) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `yuebaoid` (`yuebaoid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_yuebao_lists`
--

LOCK TABLES `lc_yuebao_lists` WRITE;
/*!40000 ALTER TABLE `lc_yuebao_lists` DISABLE KEYS */;
INSERT INTO `lc_yuebao_lists` VALUES (2,26107,'laok123',12,'利息宝1天','2',10000,1,'1650474648','1650561708',0,0.5479,'2'),(3,26110,'djtimmy',12,'利息宝1天','2',100,1,'1650560468','1650560862',0,0.0055,'2'),(4,26110,'djtimmy',13,'利息宝30天','2.5',1200,30,'1650561043','1650561059',0,2.4658,'2'),(5,26110,'djtimmy',13,'利息宝30天','2.5',1200,30,'1650561103','1650561440',0,2.4658,'2'),(6,26110,'djtimmy',12,'利息宝1天','2',1200,1,'1650474648','1650561706',0.06575,0.0658,'2'),(7,26110,'djtimmy',12,'利息宝1天','2',1200,1,'1650474648','1650561801',0.06575,0.0658,'2'),(8,26110,'djtimmy',12,'利息宝1天','2',1000,1,'1650563283','1650563316',0,0.0548,'2'),(9,26110,'djtimmy',12,'利息宝1天','2',10000,1,'1650564333','1650650734',0.54795,0.5479,'2'),(10,1,'djtimmy',12,'利息宝1天','2',1000,1,'1650651218','1650737619',0.05479,0.0548,'2');
/*!40000 ALTER TABLE `lc_yuebao_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_yuebao_log`
--

DROP TABLE IF EXISTS `lc_yuebao_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_yuebao_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `balance` float DEFAULT NULL COMMENT '结算前余额',
  `yuebaoid` int(11) DEFAULT NULL COMMENT '余额宝产品ID',
  `yebtitle` varchar(128) DEFAULT NULL COMMENT '余额宝名称',
  `lily` varchar(50) DEFAULT NULL COMMENT '利率',
  `money` int(11) DEFAULT NULL COMMENT '金额',
  `days` int(11) DEFAULT NULL COMMENT '天数',
  `start_time` varchar(15) DEFAULT NULL COMMENT '开始时间',
  `end_time` varchar(15) DEFAULT NULL COMMENT '结束时间',
  `nowprofit` float DEFAULT '0' COMMENT '当前收益',
  `finishprofit` float DEFAULT '0' COMMENT '预期收益',
  `status` char(1) DEFAULT '1',
  `closetime` varchar(15) DEFAULT NULL,
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `yuebaoid` (`yuebaoid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_yuebao_log`
--

LOCK TABLES `lc_yuebao_log` WRITE;
/*!40000 ALTER TABLE `lc_yuebao_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_yuebao_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_yuebao_uc`
--

DROP TABLE IF EXISTS `lc_yuebao_uc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_yuebao_uc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) DEFAULT NULL,
  `balance` varchar(32) DEFAULT '0',
  `trans_balance` varchar(255) NOT NULL DEFAULT '0',
  `totalprofit` varchar(32) DEFAULT '0',
  `preprofit` varchar(32) DEFAULT '0',
  `prebalance` varchar(32) DEFAULT '0',
  `remarks` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE,
  UNIQUE KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_yuebao_uc`
--

LOCK TABLES `lc_yuebao_uc` WRITE;
/*!40000 ALTER TABLE `lc_yuebao_uc` DISABLE KEYS */;
INSERT INTO `lc_yuebao_uc` VALUES (1,'26110','0.069999999999709','10000.5','0.6','0','1200','1650561020系统自动开户'),(2,'1','0','1000.1','0.1','0','0','1650646241系统自动开户'),(3,'2','0','0','0','0','0','1666502132系统自动开户');
/*!40000 ALTER TABLE `lc_yuebao_uc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lc_yuebao_uclog`
--

DROP TABLE IF EXISTS `lc_yuebao_uclog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lc_yuebao_uclog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) DEFAULT NULL,
  `balance` varchar(32) DEFAULT '0',
  `money` varchar(32) DEFAULT '0',
  `addtime` varchar(32) DEFAULT '0',
  `remarks` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_yuebao_uclog`
--

LOCK TABLES `lc_yuebao_uclog` WRITE;
/*!40000 ALTER TABLE `lc_yuebao_uclog` DISABLE KEYS */;
/*!40000 ALTER TABLE `lc_yuebao_uclog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_auth`
--

DROP TABLE IF EXISTS `system_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) DEFAULT NULL COMMENT '权限名称',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '权限状态',
  `sort` bigint(20) unsigned DEFAULT '0' COMMENT '排序权重',
  `desc` varchar(255) DEFAULT '' COMMENT '备注说明',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_auth_status` (`status`) USING BTREE,
  KEY `idx_system_auth_title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-权限';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_auth`
--

LOCK TABLES `system_auth` WRITE;
/*!40000 ALTER TABLE `system_auth` DISABLE KEYS */;
INSERT INTO `system_auth` VALUES (1,'审核人员',1,0,'审核人员','2020-05-12 15:19:42'),(2,'test',1,0,'test','2021-05-15 06:23:00'),(3,'daily',1,0,'daily','2021-05-20 05:07:57'),(4,'方法',1,0,'方法','2022-01-07 14:59:24');
/*!40000 ALTER TABLE `system_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_auth_node`
--

DROP TABLE IF EXISTS `system_auth_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_auth_node` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `auth` bigint(20) unsigned DEFAULT NULL COMMENT '角色',
  `node` varchar(200) DEFAULT NULL COMMENT '节点',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_auth_auth` (`auth`) USING BTREE,
  KEY `idx_system_auth_node` (`node`(191)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-权限-授权';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_auth_node`
--

LOCK TABLES `system_auth_node` WRITE;
/*!40000 ALTER TABLE `system_auth_node` DISABLE KEYS */;
INSERT INTO `system_auth_node` VALUES (1,1,'akszadmin'),(2,1,'akszadmin/cash'),(3,1,'akszadmin/cash/index'),(4,1,'akszadmin/cash/agree'),(5,1,'akszadmin/cash/refuse'),(6,1,'akszadmin/cash/remove'),(7,1,'akszadmin/finance'),(8,1,'akszadmin/finance/index'),(9,1,'akszadmin/finance/remove'),(10,3,'akszadmin'),(11,3,'akszadmin/users'),(12,3,'akszadmin/users/index'),(13,3,'akszadmin/users/iskqopen'),(14,3,'akszadmin/users/add'),(15,3,'akszadmin/users/edit'),(16,3,'akszadmin/users/forbid'),(17,3,'akszadmin/users/resume'),(18,3,'akszadmin/users/remove'),(19,3,'akszadmin/yuebao'),(20,3,'akszadmin/yuebao/index'),(21,3,'akszadmin/yuebao/lists');
/*!40000 ALTER TABLE `system_auth_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '' COMMENT '配置名',
  `value` varchar(500) DEFAULT '' COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_config_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,'app_name','香港数字资产交易所'),(2,'site_name','香港数字资产交易所'),(3,'app_versions','TP6'),(4,'site_copy','©版权所有 2019-2021  香港数字资产交易所'),(5,'site_icon','/upload/98aeb9928532a0c1/6fc0187cb2bfd03d.png'),(7,'miitbeian','粤ICP备16006642号-2'),(8,'storage_type','local'),(9,'storage_local_exts','doc,gif,icon,jpg,mp3,mp4,p12,pem,png,rar'),(45,'wechat_mch_id','1332187001'),(46,'wechat_mch_key','A82DC5BD1F3359081049C568D8502BC5'),(47,'wechat_mch_ssl_type','p12'),(48,'wechat_mch_ssl_p12','65b8e4f56718182d/1bc857ee646aa15d.p12'),(49,'wechat_mch_ssl_key','cc2e3e1345123930/c407d033294f283d.pem'),(50,'wechat_mch_ssl_cer','966eaf89299e9c95/7014872cc109b29a.pem'),(52,'wechat_appid','wx60a43dd8161666d4'),(53,'wechat_appsecret','9978422e0e431643d4b42868d183d60b'),(55,'wechat_push_url','消息推送地址：http://127.0.0.1:8000/wechat/api.push'),(56,'wechat_type','thr'),(57,'wechat_thr_appid','wx60a43dd8161666d4'),(58,'wechat_thr_appkey','5caf4b0727f6e46a7e6ccbe773cc955d'),(60,'wechat_thr_appurl','消息推送地址：http://127.0.0.1:2314/wechat/api.push'),(61,'component_appid','wx28b58798480874f9'),(62,'component_appsecret','8d0e1ec14ea0adc5027dd0ad82c64bc9'),(63,'component_token','P8QHTIxpBEq88IrxatqhgpBm2OAQROkI'),(64,'component_encodingaeskey','L5uFIa0U6KLalPyXckyqoVIJYLhsfrg8k9YzybZIHsx'),(65,'system_message_state','0'),(68,'sms_reg_template','您的验证码为{code}，请在十分钟内完成操作！'),(70,'store_title','测试商城'),(71,'store_order_wait_time','0.50'),(72,'store_order_clear_time','24.00'),(73,'store_order_confirm_time','60.00');
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_data`
--

DROP TABLE IF EXISTS `system_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_data` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL COMMENT '配置名',
  `value` longtext COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_data_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_data`
--

LOCK TABLES `system_data` WRITE;
/*!40000 ALTER TABLE `system_data` DISABLE KEYS */;
INSERT INTO `system_data` VALUES (1,'menudata','[{\"name\":\"请输入名称\",\"type\":\"scancode_push\",\"key\":\"scancode_push\"}]');
/*!40000 ALTER TABLE `system_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `node` varchar(200) NOT NULL DEFAULT '' COMMENT '当前操作节点',
  `geoip` varchar(15) NOT NULL DEFAULT '' COMMENT '操作者IP地址',
  `action` varchar(200) NOT NULL DEFAULT '' COMMENT '操作行为名称',
  `content` varchar(1024) NOT NULL DEFAULT '' COMMENT '操作内容描述',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '操作人用户名',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_menu`
--

DROP TABLE IF EXISTS `system_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned DEFAULT '0' COMMENT '父ID',
  `title` varchar(100) DEFAULT '' COMMENT '名称',
  `node` varchar(200) DEFAULT '' COMMENT '节点代码',
  `icon` varchar(100) DEFAULT '' COMMENT '菜单图标',
  `url` varchar(400) DEFAULT '' COMMENT '链接',
  `params` varchar(500) DEFAULT '' COMMENT '链接参数',
  `target` varchar(20) DEFAULT '_self' COMMENT '打开方式',
  `sort` int(11) unsigned DEFAULT '0' COMMENT '菜单排序',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_menu_node` (`node`(191)) USING BTREE,
  KEY `idx_system_menu_status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_menu`
--

LOCK TABLES `system_menu` WRITE;
/*!40000 ALTER TABLE `system_menu` DISABLE KEYS */;
INSERT INTO `system_menu` VALUES (1,0,'后台首页','','','akszadmin/index/main','','_self',600,1,'2018-09-05 01:59:38'),(2,0,'系统管理','','','#','','_self',300,1,'2018-09-05 02:04:52'),(3,4,'系统菜单管理','','layui-icon layui-icon-layouts','akszadmin/menu/index','','_self',1,1,'2018-09-05 02:05:26'),(4,2,'程序配置','','','#','','_self',20,1,'2018-09-05 02:07:17'),(5,12,'系统用户管理','','layui-icon layui-icon-username','akszadmin/user/index','','_self',1,1,'2018-09-05 19:10:42'),(7,12,'访问权限管理','','layui-icon layui-icon-vercode','akszadmin/auth/index','','_self',2,1,'2018-09-05 23:17:14'),(11,4,'程序参数配置','','','akszadmin/config/info','','_self',4,1,'2018-09-06 00:43:47'),(12,2,'权限管理','','','#','','_self',10,1,'2018-09-06 02:01:31'),(49,4,'系统日志管理','','layui-icon layui-icon-form','akszadmin/oplog/index','','_self',2,1,'2019-02-17 20:56:56'),(62,0,'项目管理','','','#','','_self',400,0,'2020-05-11 02:29:00'),(63,62,'合约设置','','','#','','_self',20,0,'2020-05-11 02:29:37'),(64,63,'合约列表','','','akszadmin/item/index','','_self',2,0,'2020-05-11 02:30:13'),(65,63,'合约分类','','','akszadmin/item_class/index','','_self',1,0,'2020-05-11 02:30:44'),(66,62,'合约记录','','','#','','_self',0,0,'2020-05-11 07:41:30'),(67,66,'已签合约','','','akszadmin/invest/index','','_self',0,0,'2020-05-11 07:42:03'),(68,66,'还款详情','','layui-icon layui-icon-dollar','akszadmin/invest_list/index','','_self',0,0,'2020-05-11 07:42:39'),(69,0,'用户中心','','','#','','_self',400,1,'2020-05-11 08:31:55'),(74,69,'会员管理','','','#','','_self',1,1,'2020-05-11 18:59:17'),(75,74,'会员列表','','layui-icon layui-icon-username','akszadmin/users/index','','_self',3,1,'2020-05-11 21:27:12'),(76,74,'等级设置','','layui-icon layui-icon-star','akszadmin/member/index','','_self',2,1,'2020-05-11 22:37:37'),(77,74,'银行卡列表','','fa fa-credit-card','akszadmin/bank/index','','_self',0,1,'2020-05-12 00:22:05'),(78,0,'信息管理','','','#','','_self',400,1,'2020-05-12 01:08:00'),(79,78,'文章配置','','','#','','_self',0,1,'2020-05-12 01:08:20'),(80,79,'文章列表','','layui-icon layui-icon-read','akszadmin/article/index','','_self',0,1,'2020-05-12 01:09:07'),(81,79,'文章分类','','layui-icon layui-icon-note','akszadmin/article_type/index','','_self',0,1,'2020-05-12 01:09:45'),(82,78,'站内信管理','','','#','','_self',0,1,'2020-05-12 01:52:08'),(83,82,'站内信列表','','layui-icon layui-icon-release','akszadmin/msg/index','','_self',0,1,'2020-05-12 01:53:15'),(91,2,'系统配置','','','#','','_self',30,1,'2020-05-12 07:27:03'),(92,91,'网站信息','','layui-icon layui-icon-console','akszadmin/info/set','id=1','_self',0,1,'2020-05-12 07:42:08'),(93,91,'奖励设置','','layui-icon layui-icon-rate','akszadmin/info/reward','id=1','_self',0,1,'2020-05-12 08:06:54'),(94,91,'支付设置','','fa fa-money','akszadmin/info/pay','id=1','_self',0,1,'2020-05-12 08:22:17'),(95,91,'轮播图设置','','layui-icon layui-icon-picture','akszadmin/slide/index','','_self',0,1,'2020-05-12 09:13:57'),(96,91,'系统图片设置','','layui-icon layui-icon-set','akszadmin/info/img','id=1','_self',0,1,'2020-05-12 18:27:30'),(97,74,'会员关系网','','fa fa-group','akszadmin/users/user_relation','','_self',1,1,'2020-05-15 06:36:26'),(98,91,'短信设置','','layui-icon layui-icon-dialogue','akszadmin/sms/index','','_self',0,1,'2021-01-12 00:17:36'),(99,62,'矿机设置','','','#','','_self',0,0,'2021-01-13 07:48:33'),(100,99,'矿机列表','','layui-icon layui-icon-template-1','akszadmin/mall/index','','_self',0,0,'2021-01-13 07:48:53'),(101,62,'有效矿机','','','#','','_self',0,0,'2021-01-13 17:39:13'),(102,101,'租赁列表','','layui-icon layui-icon-senior','akszadmin/mall_invest/index','','_self',0,0,'2021-01-13 17:39:40'),(103,101,'收益详情','','layui-icon layui-icon-rmb','akszadmin/mall_invest_list/index','','_self',0,0,'2021-01-13 17:40:15'),(105,69,'财务管理','','','#','','_self',0,1,'2021-02-28 22:48:50'),(106,105,'流水记录','','layui-icon layui-icon-username','akszadmin/finance/index','','_self',0,1,'2021-02-28 22:49:34'),(107,105,'充值记录','','layui-icon layui-icon-more-vertical','akszadmin/recharge/index','','_self',0,1,'2021-02-28 22:50:37'),(108,105,'提现记录','','layui-icon layui-icon-rmb','akszadmin/cash/index','','_self',0,1,'2021-02-28 22:51:08'),(109,0,'产品管理','','','#','','_self',500,1,'2021-04-12 04:28:47'),(110,109,'产品管理','','','#','','_self',0,1,'2021-04-12 04:30:57'),(111,109,'订单管理','','','#','','_self',0,1,'2021-04-12 04:31:28'),(113,110,'产品列表','','layui-icon layui-icon-template-1','akszadmin/goods/index','','_self',0,1,'2021-04-12 04:32:58'),(114,110,'风控管理','','layui-icon layui-icon-set','akszadmin/goods/risk','id=1','_self',0,1,'2021-04-12 04:35:21'),(116,111,'交易流水','','layui-icon layui-icon-form','akszadmin/order/index','','_self',0,1,'2021-04-12 04:37:23'),(117,111,'平仓日志','','layui-icon layui-icon-form','akszadmin/order_log/index','','_self',0,1,'2021-04-12 04:38:02'),(121,105,'余额宝理财','','layui-icon layui-icon-diamond','akszadmin/yuebao/index','','_self',0,1,'2021-05-16 12:49:47'),(122,105,'余额宝结算','','fa fa-tasks','akszadmin/yuebao/lists','','_self',0,1,'2021-05-16 12:52:32');
/*!40000 ALTER TABLE `system_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_queue`
--

DROP TABLE IF EXISTS `system_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_queue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '任务名称',
  `data` longtext NOT NULL COMMENT '执行参数',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '任务状态(1新任务,2处理中,3成功,4失败)',
  `preload` varchar(500) DEFAULT '' COMMENT '执行内容',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '执行时间',
  `double` tinyint(1) DEFAULT '1' COMMENT '单例模式',
  `desc` varchar(500) DEFAULT '' COMMENT '状态描述',
  `start_at` varchar(20) DEFAULT '' COMMENT '开始时间',
  `end_at` varchar(20) DEFAULT '' COMMENT '结束时间',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_queue_double` (`double`) USING BTREE,
  KEY `idx_system_queue_time` (`time`) USING BTREE,
  KEY `idx_system_queue_title` (`title`) USING BTREE,
  KEY `idx_system_queue_create_at` (`create_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_queue`
--

LOCK TABLES `system_queue` WRITE;
/*!40000 ALTER TABLE `system_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_user`
--

DROP TABLE IF EXISTS `system_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT '' COMMENT '用户账号',
  `password` varchar(32) DEFAULT '' COMMENT '用户密码',
  `qq` varchar(16) DEFAULT '' COMMENT '联系QQ',
  `mail` varchar(32) DEFAULT '' COMMENT '联系邮箱',
  `phone` varchar(16) DEFAULT '' COMMENT '联系手机',
  `login_at` datetime DEFAULT NULL COMMENT '登录时间',
  `login_ip` varchar(255) DEFAULT '' COMMENT '登录IP',
  `login_num` bigint(20) unsigned DEFAULT '0' COMMENT '登录次数',
  `authorize` varchar(255) DEFAULT '' COMMENT '权限授权',
  `tags` varchar(255) DEFAULT '' COMMENT '用户标签',
  `desc` varchar(255) DEFAULT '' COMMENT '备注说明',
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '状态(0禁用,1启用)',
  `is_deleted` tinyint(1) unsigned DEFAULT '0' COMMENT '删除(1删除,0未删)',
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_system_user_username` (`username`) USING BTREE,
  KEY `idx_system_user_status` (`status`) USING BTREE,
  KEY `idx_system_user_deleted` (`is_deleted`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统-用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_user`
--

LOCK TABLES `system_user` WRITE;
/*!40000 ALTER TABLE `system_user` DISABLE KEYS */;
INSERT INTO `system_user` VALUES (10000,'admin','afdd0b4ad2ec172c586e2150770fbf9e','','','','2022-10-31 16:22:57','0.0.0.0',35,'','','',1,0,'1999-12-31 16:00:00');
/*!40000 ALTER TABLE `system_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'wordpress'
--

--
-- Dumping routines for database 'wordpress'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 14:38:14
