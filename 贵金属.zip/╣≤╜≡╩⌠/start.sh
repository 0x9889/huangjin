while true
do
  cd public
  php index.php /index/index/order
  sleep 2
  php index.php /index/index/product
  sleep 2
done