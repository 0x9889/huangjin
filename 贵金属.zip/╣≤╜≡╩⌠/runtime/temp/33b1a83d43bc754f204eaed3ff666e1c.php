<?php /*a:1:{s:70:"D:\phpstudy_pro\WWW\www.ts.com\application\index\view\index\index.html";i:1667097738;}*/ ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>线路选择</title><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/><link href="//cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>        html {
            width: 100%;
            height: 100%;
        }

        body {
            background-color: #21212b;
        }

        .main {
            padding-top: 40%;
        }

        .main a {
            width: 80%;
            margin-bottom: 20px;
            background: rgba(0, 0, 0, .3);
            border-color: #fff;
        }

        .main h4 {
            margin-bottom: 40px;
        }
        .logowapper{padding:10px 0;}
        .logowapper img{
            height:20px;
        }
        .ad, .ad2{
            margin-top:10px;
        }
        .ad img, .ad2 img{
            max-width:100%;
        }
        .service2 img{
            max-width:100%;
        }
        .ft img{
            max-width:100%;
        }

        .service{
            margin-top:20px;
        }
        .service .title h3{
            line-height: 1;
            font-size: 23px;
            text-align: center;
            margin-bottom: 10px;
            color:#fff;
        }
        .service .title h4{
            line-height: 1;
            font-size: 12px;
            text-align: center;
            opacity: .6;
            color:#fff;
        }
        .service .itemlist{
            display:flex;
            justify-content: space-between;
        }
        .service .itemlist a{
            color:#fff;
            text-decoration:none;
        }
        .service .item{
            flex: 0 0 22%;
            color:#fff;
            text-align: center;
        }
        .service img{
            width:80px;height:80px;
        }
        .service .txt{
            margin-top:10px;
        }
        .service .item h5{
            font-size:16px;
        }
        .service .item p{
            font-size:12px;
            opacity:.8;
        }
    </style></head><body><!--<div class="main text-center">--><!--    <h4 class="text-white">优质线路选择</h4>--><!--    <a href="/index/login" class="btn btn-danger">线路一</a>--><!--    <a href="/index/login" class="btn btn-danger">线路二</a>--><!--    <a href="/index/login" class="btn btn-danger">线路三</a>--><!--</div>--><div class="logowapper"><img src="/static/wap/images/logow.png" alt=""></div><div class="ad"><img src="/static/wap/images/a1085bc31e04429c5fd3034111228b19.png" style="border-radius: 8px;max-width: 99%;max-height: 200px;"/></div><div class="ad2"><img src="/static/wap/images/2943d289a1f14ca6a31c3389093655d6.png" alt=""></div><div class="service"><div class="title"><h3>特色服务</h3><h4>CHARACTERISTIC SERVICE</h4></div><div class="itemlist"><div class="item"><a href="/index/login"><div class="img"><img src="/static/wap/images/idx1.png" alt=""></div><div class="txt"><h5>网上开户</h5><p>Open an<br>account online</p></div></a></div><div class="item"><a href="/index/login"><div class="img"><img src="/static/wap/images/idx2.png" alt=""></div><div class="txt"><h5>现货商品</h5><p>Spot<br>financing</p></div></a></div><div class="item"><a href="/index/login"><div class="img"><img src="/static/wap/images/idx3.png" alt=""></div><div class="txt"><h5>联系客服</h5><p>Billing<br>guide</p></div></a></div><div class="item"><a href="/index/login"><div class="img"><img src="/static/wap/images/idx4.png" alt=""></div><div class="txt"><h5>个人中心</h5><p>Warehousing<br>logistics</p></div></a></div></div></div><div class="service2"><img src="/static/wap/images/f5fa54b891ed0d02a0788f275d0f2464.png" alt=""></div><div class="ft"><img src="/static/wap/images/e499128dbb5a0c84fcb63f91c436ad29.png" alt=""></div></body></html>